<br><font face="Arial" color="white"><b><center>Monica Alves - Turma 22023: Programador de Informática</center></b></font><br>
<font face="Arial" color="white"><b><center>Todos os direitos reservados ;-)</center></b></font>
</body>
</html>