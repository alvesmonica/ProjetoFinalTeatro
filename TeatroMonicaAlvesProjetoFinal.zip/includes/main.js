$(document).ready(function() {
    $('.btMenu').click(function (){
        /*if($('.menu').is(':visible'))
            $('.menu').slideUp('fast');
        else*/
            $('.menu').slideDown('slow');
    });

    $('.fecharMenu').click(function (){
        $('.menu').slideUp('fast');
    });
});